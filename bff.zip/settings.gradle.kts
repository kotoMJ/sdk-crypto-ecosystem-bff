rootProject.name = "bff"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
